package com.springrest.springrest.Services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.controller.Course;
import com.springrest.springrest.dao.CourseDao;
@Service
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseDao courseDao;
	
	
	//List<Course> list;
	
	
	public  CourseServiceImpl() {
//		list =new ArrayList<>();
//		list.add(new Course(1,"Full stack java","Front end and backend"));
//		list.add(new Course(2,"python","front and backend"));
//		list.add(new Course(3,"Angular","frontEnd"));
		
	}
	 @Override
	 //get to show all
	public List<Course>getCourses(){

		return courseDao.findAll();
		
	}

//get to show one
	@SuppressWarnings("deprecation")
	@Override
	public Course getCourse(long courseId) {
//		Course c=null;
//		for(Course course:list) {
//			if(course.getId()==courseId) {
//				c=course;
//				break;
//			}
//		}
		//get id do not support in this version
		
		return courseDao.getReferenceById(courseId);
		
	}
	//insert course using Post
	  @Override
	    public Course addCourse(Course course) {
	        // Add the new course to the list
//	        list.add(course);
	        return courseDao.save(course);
	    }
	@Override
	public Course updateCourse(Course course) {
//		list.forEach(e->{
//			if(e.getId()==course.getId()) {
//				e.setTitle(course.getTitle());
//				e.setDescription(course.getDescription());
//				}
//			
//			
//		});
		courseDao.save(course);
		
		return course;
	}
	@Override
	public void deleteCourse(long parseLong) {
		
//		list=this.list.stream().filter(e->e.getId()!=parseLong).collect(Collectors.toList());
//		
		Course entity=courseDao.getReferenceById(parseLong);
		courseDao.delete(entity);
		
	}
	  
	  
	
	

}
