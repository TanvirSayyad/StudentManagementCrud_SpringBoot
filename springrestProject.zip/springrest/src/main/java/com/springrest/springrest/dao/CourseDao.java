package com.springrest.springrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springrest.springrest.controller.Course;
                                   //entity type mention here course and there type long
public interface CourseDao extends JpaRepository<Course, Long> {
	
	

}
 